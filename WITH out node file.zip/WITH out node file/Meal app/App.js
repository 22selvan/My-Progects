
import React, {useState} from 'react';
import { StyleSheet } from 'react-native';
import *as Font from 'expo-font'
import {AppLoading} from 'expo'
import MealsNavigator from './Navigation/MealsNavigator';




const fetchFonts = () => {
  return Font.loadAsync({
  'Open-Sans-Bold': require('./assets/Font/OpenSans-Bold.ttf'),
  'Open-Sans-Regular': require('./assets/Font/OpenSans-Regular.ttf'),
  
  });
  };



export default function App() {

const [fontloaded,setfontLoaded]=useState(false);
if(fontloaded){
  return (
<AppLoading
startAsync={fetchFonts}
onFinish={() => setfontLoaded(true)}

/>);}
  
  return  <MealsNavigator/>
 
}

