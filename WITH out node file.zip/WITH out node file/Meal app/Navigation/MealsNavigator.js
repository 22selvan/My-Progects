import { createStackNavigator} from 'react-navigation-stack';
import { createAppContainer } from 'react-navigation';
import { Platform } from 'react-native';

import CategoriesScreen from '../Screens/CategoriesScreens'
import MealsScreen from '../Screens/MealsScreen'
import MealDetailScreen from '../Screens/MealDetailScreen'
import Colors from '../Constants/Colors'


const MealsNavigator = createStackNavigator(
  { Categories:{ screen:
    CategoriesScreen},
  MealsScreen: {
   screen : MealsScreen
  },
  MealDetail: MealDetailScreen
}, {
  // initialRouteName: 'Categories',
  defaultNavigationOptions: {
    headerStyle: {
      backgroundColor: Platform.OS === 'android' ? Colors.primaryColor : ''
    },
    headerTintColor:
      Platform.OS === 'android' ? 'white' : Colors.primaryColor,
    headerTitle: 'A Screen'
  }
}

);

export default createAppContainer(MealsNavigator);




