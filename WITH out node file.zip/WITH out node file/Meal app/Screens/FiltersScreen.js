import React  from 'react'
import {View,StyleSheet,Text} from 'react-native';

const FiltersScreen = ()=>{
    return(
    <View style={styles.Screen}>
        <Text> The FiltersScreen!</Text>
        <Button title='Go Back' onPress={()=> {
    props.navigation.popTOTOP()
}}/>
    </View>)

};
const styles=StyleSheet.create({
    Screen:{
        flex:1,
        justifyContent:'center',
        alignItems:'center'
        
    }

})

export default FiltersScreen;