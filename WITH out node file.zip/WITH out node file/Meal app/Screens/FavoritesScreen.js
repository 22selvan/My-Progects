import React  from 'react'
import {View,StyleSheet,Text} from 'react-native';

const FavoritesScreen = ()=>{
    return(
    <View style={styles.Screen}>
        <Text> The Favorites Screen!</Text>
    </View>)

};
const styles=StyleSheet.create({
    Screen:{
        flex:1,
        justifyContent:'center',
        alignItems:'center'
        
    }

})

export default FavoritesScreen;