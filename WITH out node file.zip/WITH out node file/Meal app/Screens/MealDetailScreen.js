import React  from 'react';
import {View,StyleSheet,Text,Button} from 'react-native';
import{HeaderButtons,Ionicon} from 'react-navigation-header-buttons';

import {MEALS} from '../Data/dummy-data';
import CustomHeaderButton from '../Components/CustomHeaderButton'


const MealDetailScreen = props=>{
    
        const mealId = props.navigation.getParam('mealId');
      
        const selectedMeal = MEALS.find(meal => meal.id === mealId);
    return(
    <View style={styles.Screen}>
        <Text> <Text>{selectedMeal.title}</Text></Text>

        <Button title='Go Back Categori ' onPress={()=> {
    props.navigation.popToTop()
}}/>
        
    </View>)

};

MealDetailScreen.navigationOptions = navigationData => {
    const mealId = navigationData.navigation.getParam('mealId');
    const selectedMeal = MEALS.find(meal => meal.id === mealId);
    return {
      headerTitle: selectedMeal.title,
      headerRight:<HeaderButtons HeaderButtonComponent={CustomHeaderButton}>
         
          <Ionicon
          title="Favorite"
          iconName="ios-star"
          onPress={() => {
            console.log('Mark as favorite!');
          }}
        />
      </HeaderButtons>

    };
  };
const styles=StyleSheet.create({
    Screen:{
        flex:1,
        justifyContent:'center',
        alignItems:'center'
        
    }

})

export default MealDetailScreen;