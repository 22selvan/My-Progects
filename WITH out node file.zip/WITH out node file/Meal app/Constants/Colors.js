export default{
    primaryColor:'#4a149c',
    accentColor :'#ff6f',
}