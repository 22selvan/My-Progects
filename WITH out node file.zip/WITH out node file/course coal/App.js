
import React, { useState } from 'react';
import { Button, View, StyleSheet,  FlatList } from 'react-native';
import Goalliteams from './Components/Goalliteams';
import GoalInput from './Components/GoalInput';

export default function App() {

  const [courseGoals, setcourseGoals] = useState([]);
  const [isAddMode,setISAddMode]=useState(false)



  const addgoalHandler = GoalTittle => {
    setcourseGoals(currentGoals => [...currentGoals,
    {
      id: Math.random().toString(),
      value: GoalTittle
    }]);
     setISAddMode(false)
  }
  const removeGaolHandler = goalId => {
    setcourseGoals(currentGoals => {
      return currentGoals.filter((goal) => goal.id !== goalId)
    })
  }

  const cancelGoalAddition = () => {
    setISAddMode(false);
  }

  return (

    <View style={styles.screen}>
      <Button  title="ADD NEW" onPress={()=>setISAddMode(true)}/>
      <GoalInput visible={isAddMode} onAddGoal={addgoalHandler}  onCancel={cancelGoalAddition}/>
      <FlatList
      keyExtractor={(item) => item.id}
      data={courseGoals} renderItem={itemdata =>
      <Goalliteams id={itemdata.item.id}
      onDelete={removeGaolHandler}
      title={itemdata.item.value} />}
      />
    </View>


  );
}

const styles = StyleSheet.create({
  screen: { padding: 50 },






})
