import React, { useState } from 'react';
import { View, TextInput, Button, StyleSheet, Modal } from 'react-native';


const GoalInput = props => {
    const [enteredGoal, setEnteredGoal] = useState("");

    const goaliputHandler = (enterText) => {
        setEnteredGoal(enterText)
    };

    const addGoalHandler = () => {
        props.onAddGoal(enteredGoal)
        setEnteredGoal('');
    };



    return (<Modal visible={props.visible} animationType="slide">
        <View style={styles.inputcontainer}>
            <TextInput placeholder='course goal'
                style={styles.input} onChangeText={goaliputHandler}
                value={enteredGoal} />
                <View  style={styles.Buttoncontainer}>
                <Button title="CHANCEL" color="red" onPress={props.onCancel}/>
                <Button title='ADD' onPress={addGoalHandler} />
                </View>
       
        </View>
    </Modal>);

};

const styles = StyleSheet.create({
    inputcontainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center'
    },

    input: {
        width: '80%',
        borderColor: 'black',
        borderWidth: 1,
        padding: 10
    },
    Buttoncontainer:{
        flexDirection:'row',
        justifyContent: 'space-around',
        width:'70%'
    }


})

export default GoalInput;