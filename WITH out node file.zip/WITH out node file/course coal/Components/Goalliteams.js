import React from 'react';
import { Text, View, StyleSheet ,TouchableOpacity} from 'react-native';

const Goalliteams = props => {
    return (
    
        <TouchableOpacity onPress={props.onDelete.bind(this,props.id)}>
    <View style={styles.listitems}>
        <Text> {props.title}</Text>
    </View>
    </TouchableOpacity> 
    );

}

const styles = StyleSheet.create({
    listitems: {
        borderColor: 'black',
        backgroundColor: 'skyblue',
        marginVertical: 10,
        borderWidth: 1,
        padding: 10
    },

})

export default Goalliteams;